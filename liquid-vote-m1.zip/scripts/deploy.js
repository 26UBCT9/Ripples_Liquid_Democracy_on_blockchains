const { ethers, network, artifacts } = require("hardhat");
const fs = require("fs");
const path = require("path");

// Canonical Semaphore v4 address on public testnets (verify against
// https://docs.semaphore.pse.dev/deployed-contracts before deploying).
const DEFAULT_SEPOLIA_SEMAPHORE = "0x06d1530c829366A7fff0069e77c5af6A6FA7db2E";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log(`Deploying to ${network.name} as ${deployer.address}`);

  const forwarder = await (await ethers.getContractFactory("Forwarder")).deploy("LiquidVoteForwarder");
  await forwarder.waitForDeployment();

  const citizens = await (await ethers.getContractFactory("CitizenRegistry")).deploy(deployer.address);
  await citizens.waitForDeployment();

  let semaphoreAddress = process.env.SEMAPHORE_ADDRESS;
  if (!semaphoreAddress) {
    if (network.name === "sepolia") {
      semaphoreAddress = DEFAULT_SEPOLIA_SEMAPHORE;
      console.log(`Using canonical Semaphore at ${semaphoreAddress} (set SEMAPHORE_ADDRESS to override)`);
    } else {
      const mock = await (await ethers.getContractFactory("MockSemaphore")).deploy();
      await mock.waitForDeployment();
      semaphoreAddress = await mock.getAddress();
      console.log(`Deployed MockSemaphore at ${semaphoreAddress}`);
    }
  }

  const delegations = await (
    await ethers.getContractFactory("DelegationRegistry")
  ).deploy(await forwarder.getAddress(), await citizens.getAddress());
  await delegations.waitForDeployment();

  const controller = await (
    await ethers.getContractFactory("VoteController")
  ).deploy(
    await forwarder.getAddress(),
    deployer.address,
    await citizens.getAddress(),
    await delegations.getAddress(),
    semaphoreAddress
  );
  await controller.waitForDeployment();

  const { chainId } = await ethers.provider.getNetwork();
  const addresses = {
    chainId: Number(chainId),
    network: network.name,
    forwarder: await forwarder.getAddress(),
    citizenRegistry: await citizens.getAddress(),
    delegationRegistry: await delegations.getAddress(),
    voteController: await controller.getAddress(),
    semaphore: semaphoreAddress,
  };

  const abis = {};
  for (const name of ["Forwarder", "CitizenRegistry", "DelegationRegistry", "VoteController"]) {
    abis[name] = (await artifacts.readArtifact(name)).abi;
  }

  const deployment = { ...addresses, abi: abis };

  fs.mkdirSync(path.join(__dirname, "..", "deployments"), { recursive: true });
  fs.writeFileSync(
    path.join(__dirname, "..", "deployments", `${network.name}.json`),
    JSON.stringify(deployment, null, 2)
  );
  const frontendDir = path.join(__dirname, "..", "frontend", "src");
  if (fs.existsSync(frontendDir)) {
    fs.writeFileSync(path.join(frontendDir, "deployment.json"), JSON.stringify(deployment, null, 2));
  }

  console.log(JSON.stringify(addresses, null, 2));
  console.log("Wrote deployments/%s.json and frontend/src/deployment.json", network.name);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
