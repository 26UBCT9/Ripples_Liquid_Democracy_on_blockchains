import { useCallback, useEffect, useState } from "react";
import { connectWallet, contracts, deployment, isDeployed, short, web3 } from "./lib/chain";
import { PHASES } from "./topics";
import VoteView from "./views/VoteView";
import ResultsView from "./views/ResultsView";
import PaperAdmin from "./views/PaperAdmin";
import CitizenAdmin from "./views/CitizenAdmin";

const TABS = ["Vote", "Results", "Paper administration", "Citizen administration"];

export default function App() {
  const [account, setAccount] = useState(null);
  const [tab, setTab] = useState(0);
  const [isCitizen, setIsCitizen] = useState(false);
  const [papers, setPapers] = useState([]);
  const [flash, setFlash] = useState(null);

  const notify = (text, kind = "info") => {
    setFlash({ text, kind });
    setTimeout(() => setFlash(null), 6000);
  };

  const refresh = useCallback(async () => {
    if (!account || !isDeployed) return;
    const { controller, citizens } = contracts();
    setIsCitizen(await citizens.methods.isCitizen(account).call());
    const count = Number(await controller.methods.paperCount().call());
    const list = [];
    for (let id = count; id >= 1 && list.length < 20; id--) {
      const p = await controller.methods.getPaper(id).call();
      const phase = Number(await controller.methods.phaseOf(id).call());
      const matters = await Promise.all(
        p.matterIds.map(async (mid) => {
          const m = await controller.methods.getMatter(mid).call();
          return {
            id: mid.toString(),
            topicId: Number(m.topicId),
            text: m.text,
            yes: m.yes.toString(),
            no: m.no.toString(),
          };
        })
      );
      list.push({
        id,
        title: p.title,
        phase,
        phaseName: PHASES[phase],
        delegationEnd: Number(p.delegationEnd),
        registrationEnd: Number(p.registrationEnd),
        votingEnd: Number(p.votingEnd),
        revealEnd: Number(p.revealEnd),
        finalized: p.finalized,
        matters,
      });
    }
    setPapers(list);
  }, [account]);

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 8000);
    return () => clearInterval(t);
  }, [refresh]);

  useEffect(() => {
    if (!window.ethereum) return;
    const onAccounts = (a) => setAccount(a[0] ? web3.utils.toChecksumAddress(a[0]) : null);
    window.ethereum.on?.("accountsChanged", onAccounts);
    return () => window.ethereum.removeListener?.("accountsChanged", onAccounts);
  }, []);

  if (!window.ethereum) {
    return <Shell><p className="notice">No wallet found. Install MetaMask to use Liquid Vote.</p></Shell>;
  }
  if (!isDeployed) {
    return (
      <Shell>
        <p className="notice">
          No deployment found. Run <code>npm run deploy:local</code> (or <code>deploy:sepolia</code>) in the repo
          root, then rebuild the frontend.
        </p>
      </Shell>
    );
  }

  const viewProps = { account, papers, refresh, notify, isCitizen };

  return (
    <Shell
      right={
        account ? (
          <div className="wallet">
            <span className={`chip ${isCitizen ? "chip-ok" : ""}`}>{isCitizen ? "CITIZEN" : "NO VOTING RIGHT"}</span>
            <span className="mono">{short(account)}</span>
          </div>
        ) : (
          <button className="btn btn-red" onClick={async () => setAccount(await connectWallet())}>
            Connect wallet
          </button>
        )
      }
    >
      <nav className="tabs">
        {TABS.map((t, i) => (
          <button key={t} className={`tab ${tab === i ? "tab-active" : ""}`} onClick={() => setTab(i)}>
            {t}
          </button>
        ))}
      </nav>
      {flash && <div className={`flash flash-${flash.kind}`}>{flash.text}</div>}
      {!account ? (
        <p className="notice">Connect a wallet to continue. Voters never need ETH: every voter action is signed and relayed gas-free.</p>
      ) : (
        <main>
          {tab === 0 && <VoteView {...viewProps} />}
          {tab === 1 && <ResultsView {...viewProps} />}
          {tab === 2 && <PaperAdmin {...viewProps} />}
          {tab === 3 && <CitizenAdmin {...viewProps} />}
        </main>
      )}
      <footer className="foot">
        <span>Network: {deployment.network} · chain {deployment.chainId}</span>
        <span className="mono">controller {short(deployment.voteController)}</span>
      </footer>
    </Shell>
  );
}

function Shell({ children, right }) {
  return (
    <div className="page">
      <header className="masthead">
        <div>
          <h1 className="wordmark">
            LIQUID<span className="red">VOTE</span>
          </h1>
          <p className="subtitle">Direct democracy with per-topic delegation, on Ethereum</p>
        </div>
        {right}
      </header>
      {children}
    </div>
  );
}
