import { useState } from "react";
import { contracts, web3 } from "../lib/chain";

export default function CitizenAdmin({ account, notify }) {
  const [address, setAddress] = useState("");
  const [status, setStatus] = useState(null);
  const [busy, setBusy] = useState(false);

  const act = async (method) => {
    try {
      setBusy(true);
      const { citizens } = contracts();
      await citizens.methods[method](address).send({ from: account });
      notify(method === "issue" ? "Citizen token issued." : "Citizen token revoked.", "ok");
      setStatus(await citizens.methods.isCitizen(address).call());
    } catch (e) {
      notify(e.message, "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel">
      <h2>Citizen registry</h2>
      <p className="hint">
        Government action (ISSUER_ROLE). One soulbound token per citizen establishes the vote; issuance stands in for
        the civil register. The token never transfers.
      </p>
      <label>
        Citizen address
        <input className="mono" value={address} placeholder="0x…" onChange={(e) => setAddress(e.target.value)} />
      </label>
      <div className="row">
        <button
          className="btn"
          disabled={!web3.utils.isAddress(address)}
          onClick={async () => setStatus(await contracts().citizens.methods.isCitizen(address).call())}
        >
          Check
        </button>
        <button className="btn btn-red" disabled={busy || !web3.utils.isAddress(address)} onClick={() => act("issue")}>
          Issue voting right
        </button>
        <button className="btn" disabled={busy || !web3.utils.isAddress(address)} onClick={() => act("revoke")}>
          Revoke
        </button>
        {status !== null && <span className={`chip ${status ? "chip-ok" : ""}`}>{status ? "CITIZEN" : "NOT A CITIZEN"}</span>}
      </div>
    </section>
  );
}
