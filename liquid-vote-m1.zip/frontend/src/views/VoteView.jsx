import { useEffect, useState } from "react";
import {
  contracts,
  deployment,
  loadBallot,
  publicCommitment,
  randomSalt,
  sendGasless,
  short,
  storeBallot,
  web3,
} from "../lib/chain";
import { TOPICS } from "../topics";

export default function VoteView({ account, papers, refresh, notify, isCitizen }) {
  return (
    <div>
      <DelegationPanel account={account} notify={notify} refresh={refresh} isCitizen={isCitizen} />
      <h2 className="rule">Voting papers</h2>
      {papers.length === 0 && <p className="notice">No voting papers yet.</p>}
      {papers.map((p) => (
        <Paper key={p.id} paper={p} account={account} notify={notify} refresh={refresh} />
      ))}
    </div>
  );
}

function DelegationPanel({ account, notify, refresh, isCitizen }) {
  const [current, setCurrent] = useState({});
  const [inputs, setInputs] = useState({});
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const { delegations } = contracts();
    const next = {};
    for (let t = 0; t < 8; t++) {
      next[t] = await delegations.methods.delegateOf(account, t).call();
    }
    setCurrent(next);
  };
  useEffect(() => {
    load();
  }, [account]);

  const change = async (topicId, clear) => {
    try {
      setBusy(true);
      const { delegations } = contracts();
      const data = clear
        ? delegations.methods.clearDelegate(topicId).encodeABI()
        : delegations.methods.setDelegate(topicId, inputs[topicId]).encodeABI();
      await sendGasless(account, deployment.delegationRegistry, data, 400000);
      notify(clear ? "Delegation cleared." : "Delegation set.", "ok");
      setInputs({ ...inputs, [topicId]: "" });
      await load();
      refresh();
    } catch (e) {
      notify(e.message, "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel">
      <h2>Standing delegations</h2>
      <p className="hint">
        One hop per topic. A paper counts the delegations that stand at its snapshot (end of its delegation window);
        your own ballot always overrides. Changes are signed by you and relayed gas-free.
      </p>
      {!isCitizen && <p className="notice">This account holds no citizen token, so it cannot delegate or vote.</p>}
      <div className="topic-grid">
        {TOPICS.map((name, t) => {
          const zero = !current[t] || /^0x0+$/.test(current[t]);
          return (
            <div className="topic-row" key={t}>
              <div>
                <span className="eyebrow">Topic {t}</span>
                <strong>{name}</strong>
                <div className="mono small">{zero ? "no delegate" : `→ ${short(current[t])}`}</div>
              </div>
              <div className="topic-actions">
                <input
                  className="mono"
                  placeholder="0x… delegate"
                  value={inputs[t] || ""}
                  onChange={(e) => setInputs({ ...inputs, [t]: e.target.value })}
                  disabled={!isCitizen || busy}
                />
                <button
                  className="btn"
                  disabled={!isCitizen || busy || !web3.utils.isAddress(inputs[t] || "")}
                  onClick={() => change(t, false)}
                >
                  Set
                </button>
                <button className="btn" disabled={!isCitizen || busy || zero} onClick={() => change(t, true)}>
                  Clear
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function Countdown({ paper }) {
  const [, tick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => tick((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, []);
  const now = Math.floor(Date.now() / 1000);
  const next =
    paper.phase === 0
      ? ["registration opens", paper.delegationEnd]
      : paper.phase === 1
        ? ["voting opens", paper.registrationEnd]
        : paper.phase === 2
          ? ["reveal opens", paper.votingEnd]
          : paper.phase === 3
            ? ["paper closes", paper.revealEnd]
            : null;
  if (!next) return null;
  const s = Math.max(0, next[1] - now);
  const fmt = `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m ${s % 60}s`;
  return (
    <span className="mono small">
      {next[0]} in {fmt}
    </span>
  );
}

function Paper({ paper, account, notify, refresh }) {
  return (
    <article className="sheet">
      <header className="sheet-head">
        <div>
          <span className="eyebrow">Paper №{paper.id}</span>
          <h3>{paper.title}</h3>
        </div>
        <div className="sheet-meta">
          <span className={`phase phase-${paper.phase}`}>{paper.phaseName}</span>
          <Countdown paper={paper} />
        </div>
      </header>

      {paper.phase === 1 && <RegistrationRow paper={paper} account={account} notify={notify} refresh={refresh} />}

      {paper.matters.map((m) => (
        <Matter key={m.id} paper={paper} matter={m} account={account} notify={notify} refresh={refresh} />
      ))}
    </article>
  );
}

function RegistrationRow({ paper, account, notify, refresh }) {
  const topics = [...new Set(paper.matters.map((m) => m.topicId))];
  const [status, setStatus] = useState({});

  useEffect(() => {
    (async () => {
      const { controller } = contracts();
      const next = {};
      for (const t of topics) {
        next[t] = await controller.methods.anonMode(paper.id, t, account).call();
      }
      setStatus(next);
    })();
  }, [paper.id, account]);

  return (
    <div className="register">
      <strong>Anonymous voting registration is open.</strong>
      <p className="hint">
        Available per topic if you neither delegated the topic nor received delegations at the snapshot. Registration
        is visible on-chain; the ballot later is not linkable to you. Ballot proving arrives with milestone M2 -
        registration is already live.
      </p>
      {topics.map((t) => (
        <button
          key={t}
          className="btn"
          disabled={status[t]}
          onClick={async () => {
            try {
              // M2 will insert a real Semaphore identity commitment derived
              // from a wallet signature; until then a placeholder registers.
              const { controller } = contracts();
              const commitment = web3.utils.hexToNumberString(randomSalt());
              const data = controller.methods.registerAnonymous(paper.id, t, commitment).encodeABI();
              await sendGasless(account, deployment.voteController, data, 900000);
              notify(`Registered anonymously for "${TOPICS[t]}".`, "ok");
              setStatus({ ...status, [t]: true });
              refresh();
            } catch (e) {
              notify(e.message, "err");
            }
          }}
        >
          {status[t] ? `Registered: ${TOPICS[t]}` : `Register: ${TOPICS[t]}`}
        </button>
      ))}
    </div>
  );
}

function Matter({ paper, matter, account, notify, refresh }) {
  const [stored, setStored] = useState(() => loadBallot(account, matter.id));
  const [committed, setCommitted] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [anon, setAnon] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setStored(loadBallot(account, matter.id));
    (async () => {
      const { controller } = contracts();
      const c = await controller.methods.publicCommitOf(matter.id, account).call();
      setCommitted(!/^0x0+$/.test(c));
      setRevealed(await controller.methods.publicRevealed(matter.id, account).call());
      setAnon(await controller.methods.anonMode(paper.id, matter.topicId, account).call());
    })();
  }, [matter.id, account, paper.phase]);

  const commit = async (choice) => {
    try {
      setBusy(true);
      const salt = randomSalt();
      const commitment = publicCommitment(matter.id, account, choice, salt);
      const { controller } = contracts();
      const data = controller.methods.commitPublic(matter.id, commitment).encodeABI();
      await sendGasless(account, deployment.voteController, data, 500000);
      storeBallot(account, matter.id, { choice, salt });
      setStored({ choice, salt });
      setCommitted(true);
      notify("Ballot committed. Keep this browser: the salt for your reveal is stored here.", "ok");
    } catch (e) {
      notify(e.message, "err");
    } finally {
      setBusy(false);
    }
  };

  const reveal = async () => {
    try {
      setBusy(true);
      const { controller } = contracts();
      const data = controller.methods.revealPublic(matter.id, stored.choice, stored.salt).encodeABI();
      await sendGasless(account, deployment.voteController, data, 700000);
      setRevealed(true);
      notify("Ballot revealed and tallied.", "ok");
      refresh();
    } catch (e) {
      notify(e.message, "err");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="ballot">
      <div className="ballot-q">
        <span className="eyebrow">{TOPICS[matter.topicId]}</span>
        <p className="question">{matter.text}</p>
        <span className="mono small">Matter №{matter.id}</span>
      </div>
      <div className="ballot-a">
        {paper.phase < 2 && <span className="stamp stamp-wait">VOTING NOT OPEN</span>}
        {paper.phase === 2 && anon && <span className="stamp">ANONYMOUS · BALLOT VIA M2 CLI</span>}
        {paper.phase === 2 && !anon && !committed && (
          <div className="janein">
            <button className="btn-vote" disabled={busy} onClick={() => commit(true)}>
              JA
            </button>
            <button className="btn-vote" disabled={busy} onClick={() => commit(false)}>
              NEIN
            </button>
          </div>
        )}
        {paper.phase === 2 && committed && <span className="stamp">COMMITTED{stored ? ` · ${stored.choice ? "JA" : "NEIN"}` : ""}</span>}
        {paper.phase === 3 && committed && !revealed && (
          stored ? (
            <button className="btn btn-red" disabled={busy} onClick={reveal}>
              Reveal {stored.choice ? "JA" : "NEIN"}
            </button>
          ) : (
            <span className="stamp stamp-wait">SALT NOT IN THIS BROWSER</span>
          )
        )}
        {paper.phase === 3 && revealed && <span className="stamp stamp-ok">REVEALED</span>}
        {paper.phase === 3 && !committed && <span className="stamp stamp-wait">NO COMMITMENT</span>}
        {paper.phase >= 4 && <span className="stamp stamp-wait">CLOSED</span>}
      </div>
    </div>
  );
}
