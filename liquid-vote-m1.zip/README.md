# Liquid Vote

Swiss-style liquid democracy on Ethereum: government-issued voting rights (soulbound tokens), voting papers whose matters belong to 8 fixed topics, yes/no ballots, standing per-topic delegation with own-vote override, optional anonymous ballots (Semaphore v4), commit-reveal so nothing is readable before the reveal phase, and a government relayer so voters never need ETH.

The full design rationale lives in `liquid-voting-architecture.md` (spec v0.4). This repo is milestone **M1**: the complete public core plus the on-chain anonymous path (verified against a mock; real browser proving is M2).

## Repo layout

```
contracts/        CitizenRegistry, DelegationRegistry, VoteController, Forwarder, mocks/
test/             18 Hardhat tests incl. every reveal order of the spec §5 scenario
scripts/deploy.js deploys everything, exports addresses + ABIs for frontend & relayer
relayer/          government relayer (Express): /relay/meta, /relay/anonymous, /health
frontend/         React + web3.js v4, four views (Vote, Results, Paper admin, Citizen admin)
```

## Prerequisites

Node 20+, npm, MetaMask in the browser.

```bash
npm install                # repo root (hardhat, contracts)
cd relayer && npm install && cd ..
cd frontend && npm install && cd ..
```

## Tests

```bash
npm test
```

Covers: soulbound behaviour; checkpoint snapshots exactly at the boundary; the spec §5 tally scenario in all reveal orders (delegate first / delegator first / delegate never reveals), the dual-role chain A→B→C; anonymity Rule 1 (delegation and anonymity mutually exclusive per topic, post-snapshot delegations don't block registration); scope/message binding and nullifier uniqueness; phase gating; and the gasless path (attribution to the signer, replay rejection, full gasless commit+reveal).

## Local demo

Four terminals:

```bash
npm run node               # 1. local chain, mines every 5s so phases advance
npm run deploy:local       # 2. deploys + writes deployments/localhost.json and frontend/src/deployment.json
cd relayer && npm start    # 3. relayer on :3001 (dev default key = hardhat account #1)
cd frontend && npm run dev # 4. app on :5173
```

MetaMask: add network `http://127.0.0.1:8545`, chain id `31337`. Import the government account (hardhat #0) for the admin tabs:

```
0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
```

(Hardhat's well-known dev keys - never use them anywhere real.)

Walkthrough:

1. **Citizen administration** (as government): create a *fresh* MetaMask account for your voter - do not fund it - and issue it a voting right. The zero balance is the point: every voter action below is gasless.
2. **Paper administration**: publish a paper. For a quick demo set the four deadlines a few minutes apart (e.g. +2 / +4 / +6 / +8 min). The end of the delegation window is the snapshot.
3. **Vote** (as the voter): during *Delegation*, set a standing delegate for a topic - MetaMask asks for a signature, not a transaction; the relayer pays. During *Registration*, optionally register a second, undelegated account for anonymous voting. During *Voting*, commit JA/NEIN (the salt is kept in this browser's localStorage). During *Reveal*, reveal - only now does the tally move.
4. **Results**: sealed until reveal, live afterwards; finalize once ended. Delegated weight shows up under the delegate's reveal and shrinks when a delegator reveals their own ballot (override), in any order.

## Sepolia

1. Copy `.env.example` to `.env`: RPC URL, deployer key, optionally override `SEMAPHORE_ADDRESS` (verify the canonical v4 address for Sepolia at docs.semaphore.pse.dev/deployed-contracts).
2. Faucet-fund the deployer and the relayer wallet.
3. `npm run deploy:sepolia`
4. `relayer/.env`: `RPC_URL=<sepolia rpc>`, `DEPLOYMENT=../deployments/sepolia.json`, `RELAYER_KEY=<relayer key>`.
5. Frontend: `VITE_RELAYER_URL=<relayer url> npm run dev` (or build). `deployment.json` was already rewritten by the deploy.
6. Optional: `npx hardhat verify --network sepolia <address> <constructor args>` per contract.

Suggested test schedule on Sepolia: delegation 15 min, registration 15 min, voting 30 min, reveal 30 min. Walk one account through delegation plus a later override, a second through anonymous registration; also set one delegation *after* the snapshot and confirm it only affects the next paper (checkpoint boundary).

## Design properties worth knowing

- **Zero ETH for voters**: token mint paid by government; delegation, registration, public commits/reveals ride ERC-2771 meta-transactions; anonymous ballots are submitted by the relayer's own account with no voter signature at all (the proof is the authorization). Self-paid fallback always works if the relayer censors.
- **Order-independent tally**: reveals apply override arithmetic in O(1); any reveal order gives the same result. Unrevealed commitments are abstentions.
- **Rule 1**: per topic and paper, a voter is either in the delegation graph or anonymous, never both - checked at the snapshot, so post-snapshot delegation changes don't lock anyone out of the current paper.
- **Relayer griefing cap**: delegation flips are the one unbounded relayed action; the relayer caps them per voter per hour (`MAX_DELEGATION_RELAYS_PER_HOUR`).
- Known limitations (government trust root, no receipt-freeness on the public path, relayer metadata, anonymity-set size, reveal UX) are discussed in the architecture doc §11.

## M2 - real anonymity (next)

The chain side is already live (per-(paper,topic) Semaphore groups, scope/message binding, nullifiers). To finish:

1. Frontend identity: `@semaphore-protocol/core` - `new Identity(await signer.signMessage("liquid-vote identity v1"))`; register its commitment.
2. Group sync: rebuild the group from `MemberAdded` events (or the Semaphore subgraph) for the paper/topic group id.
3. Proof: `generateProof(identity, group, message = ballot commitment, scope = scopeOf(matterId))`, then POST to `/relay/anonymous` (kind `commit`), later `reveal` with the salt.
4. Tests: add a slow e2e suite deploying the real `Semaphore.sol` + verifier with `@semaphore-protocol/proof` instead of the mock.

M3 adds the voting-history view and the SSI experiment on top.
